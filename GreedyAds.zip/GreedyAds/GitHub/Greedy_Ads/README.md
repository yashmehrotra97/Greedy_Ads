# Greedy_Ads
Interview assignment for Greedy Games
